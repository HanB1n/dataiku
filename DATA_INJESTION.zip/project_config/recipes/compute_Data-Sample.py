# -*- coding: utf-8 -*-
"""Sample up to 100 values independently from every source column."""

import csv
import itertools
import json
import os
import random
from datetime import datetime, timezone

import dataiku
import pandas as pd


OUTPUT_DATASET = "Data-Sample"

SAMPLE_SIZE = 100
MAX_VALUE_LENGTH = 1000
SUPPORTED_EXTENSIONS = {".csv", ".tsv", ".txt"}


PROJECT_VARIABLES = dataiku.get_custom_variables()
INPUT_FOLDER_ID = str(
    PROJECT_VARIABLES.get("STAGING_FOLDER_ID") or ""
).strip()
if not INPUT_FOLDER_ID:
    raise ValueError("Set the Dataiku project variable STAGING_FOLDER_ID")


input_folder = dataiku.Folder(INPUT_FOLDER_ID)
output_dataset = dataiku.Dataset(OUTPUT_DATASET)


def load_metadata(file_path, available_paths):
    metadata_path = file_path + "_metadata"
    if metadata_path not in available_paths:
        return {}

    with input_folder.get_download_stream(metadata_path) as stream:
        return json.loads(stream.read().decode("utf-8-sig"))


def decoded_lines(byte_stream):
    first_line = True
    while True:
        raw_line = byte_stream.readline()
        if not raw_line:
            return
        encoding = "utf-8-sig" if first_line else "utf-8"
        yield raw_line.decode(encoding)
        first_line = False


def open_csv_reader(byte_stream, extension):
    # Invalid UTF-8 fails visibly rather than changing multilingual text.
    remaining_lines = decoded_lines(byte_stream)
    preview_lines = list(itertools.islice(remaining_lines, 20))

    preview = "".join(preview_lines)
    fallback = "\t" if extension == ".tsv" else ","
    try:
        delimiter = csv.Sniffer().sniff(preview, delimiters=",;\t|").delimiter
    except csv.Error:
        delimiter = fallback

    lines = itertools.chain(preview_lines, remaining_lines)
    return csv.reader(lines, delimiter=delimiter), delimiter


def sample_file(file_path):
    extension = os.path.splitext(file_path)[1].lower()

    with input_folder.get_download_stream(file_path) as byte_stream:
        reader, delimiter = open_csv_reader(byte_stream, extension)

        try:
            headers = next(reader)
        except StopIteration:
            raise ValueError("The file is empty")

        if not headers:
            raise ValueError("No header row was found")

        reservoirs = [[] for _ in headers]
        values_seen = [0 for _ in headers]
        random_generators = [
            random.Random("{}:{}".format(file_path, position))
            for position in range(1, len(headers) + 1)
        ]
        row_count = 0

        for row in reader:
            if not row:
                continue

            row_count += 1
            aligned_row = (list(row) + [""] * len(headers))[:len(headers)]

            for index, value in enumerate(aligned_row):
                values_seen[index] += 1
                seen = values_seen[index]
                value = str(value)[:MAX_VALUE_LENGTH]

                if len(reservoirs[index]) < SAMPLE_SIZE:
                    reservoirs[index].append(value)
                else:
                    replacement = random_generators[index].randint(1, seen)
                    if replacement <= SAMPLE_SIZE:
                        reservoirs[index][replacement - 1] = value

    columns = []
    for position, header in enumerate(headers, start=1):
        samples = reservoirs[position - 1]
        columns.append({
            "column_position": position,
            "column_name": str(header),
            "values_seen": values_seen[position - 1],
            "sample_count": len(samples),
            "sample_values": samples,
        })

    return {
        "file_name": os.path.basename(file_path),
        "file_path": file_path,
        "row_count": row_count,
        "column_count": len(headers),
        "delimiter": delimiter,
        "sampling": {
            "method": "independent_reservoir_sampling",
            "sample_size_per_column": SAMPLE_SIZE,
            "includes_empty_cells": True,
        },
        "columns": columns,
    }


available_paths = set(input_folder.list_paths_in_partition())
results = []

for file_path in sorted(available_paths):
    extension = os.path.splitext(file_path)[1].lower()
    if extension not in SUPPORTED_EXTENSIONS:
        continue

    result = {
        "file_path": file_path,
        "file_name": os.path.basename(file_path),
        "source_file_reference": "",
        "sample_generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "row_count": 0,
        "column_count": 0,
        "delimiter": "",
        "llm_payload_json": "{}",
        "parse_status": "SUCCESS",
        "parse_error": "",
    }

    try:
        metadata = load_metadata(file_path, available_paths)
        payload = sample_file(file_path)
        payload["lineage"] = metadata

        result.update({
            "source_file_reference": str(
                metadata.get("source_file_reference")
                or metadata.get("source_file_md5")
                or ""
            ),
            "row_count": payload["row_count"],
            "column_count": payload["column_count"],
            "delimiter": payload["delimiter"],
            "llm_payload_json": json.dumps(payload, ensure_ascii=False),
        })
    except Exception as error:
        result.update({
            "parse_status": "ERROR",
            "parse_error": str(error)[:2000],
        })

    results.append(result)


if not results:
    raise ValueError("No CSV, TSV, or TXT files were found")

output_dataset.write_with_schema(pd.DataFrame(results))
