"""Dash webapp for uploading raw delimited files to a Dataiku managed folder.

Dataiku creates the Dash ``app`` object. Paste this file into the Python tab of
a Dataiku Dash webapp; do not add ``app = Dash(...)``.
"""

import base64
import binascii
import hashlib
import io
import json
import os
import re
from datetime import datetime, timedelta, timezone

import dataiku
from dash import Input, Output, State, callback_context, dcc, html
from dash.exceptions import PreventUpdate
from flask import request


# Cross-project managed-folder ID for the raw upload destination.
UPLOAD_FOLDER_ID = "DATA_INJESTION.ATNrnxuc"

ALLOWED_EXTENSIONS = {".csv", ".tsv", ".txt"}

# dcc.Upload sends base64 data through the browser and webapp process. Keep this
# materially lower than a streaming HTTP upload limit. Increase only after load
# testing the browser, reverse proxy, and Dataiku webapp container.
MAX_FILE_SIZE_MB = 100
MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024
GMT_PLUS_8 = timezone(timedelta(hours=8), name="GMT+8")

upload_folder = dataiku.Folder(UPLOAD_FOLDER_ID)
api_client = dataiku.api_client()


COLORS = {
    "ink": "#172033",
    "muted": "#667085",
    "line": "#d9e0ea",
    "surface": "#ffffff",
    "canvas": "#f3f6fa",
    "primary": "#2457d6",
    "primary_soft": "#edf3ff",
    "success": "#087a55",
    "success_soft": "#eaf8f2",
    "danger": "#b42318",
    "danger_soft": "#fff0ee",
}


def decode_upload(contents):
    if not contents or "," not in contents:
        raise ValueError("The browser did not provide valid upload content.")

    metadata, encoded_content = contents.split(",", 1)
    if ";base64" not in metadata:
        raise ValueError("The uploaded content is not base64 encoded.")

    try:
        return base64.b64decode(encoded_content, validate=True)
    except (binascii.Error, ValueError) as error:
        raise ValueError("The uploaded file could not be decoded.") from error


def get_authenticated_uploader():
    """Return the Dataiku user represented by the current browser request."""
    auth_info = api_client.get_auth_info_from_browser_headers(
        dict(request.headers)
    )
    uploader = auth_info.get("associatedDSSUser") or auth_info.get(
        "authIdentifier"
    )
    if not uploader:
        raise ValueError(
            "Your authenticated Dataiku username could not be determined. "
            "Anonymous uploads are not permitted."
        )
    return str(uploader)


def normalize_record_date(value):
    if value is None or not str(value).strip():
        return None
    try:
        return datetime.strptime(str(value), "%Y-%m-%d").date().isoformat()
    except (TypeError, ValueError):
        raise ValueError("Enter a valid source record date or leave it empty.")


def prepare_upload(original_filename, contents):
    original_filename = str(original_filename or "")
    if not original_filename:
        raise ValueError("The file has no name.")
    if original_filename in {".", ".."} or any(
        character in original_filename for character in ("/", "\\", "\x00")
    ):
        raise ValueError(
            "The filename contains a path separator or invalid character."
        )

    extension = os.path.splitext(original_filename)[1].lower()
    if extension not in ALLOWED_EXTENSIONS:
        raise ValueError("Only CSV, TSV, and TXT files are allowed.")

    raw_bytes = decode_upload(contents)
    if len(raw_bytes) > MAX_FILE_SIZE_BYTES:
        raise ValueError(
            "The file exceeds the {} MB Dash upload limit.".format(
                MAX_FILE_SIZE_MB
            )
        )

    return raw_bytes, hashlib.md5(raw_bytes).hexdigest()


def build_md5_index(existing_paths):
    """Index uploaded source files using their per-file metadata objects."""
    index = {}
    for metadata_path in sorted(existing_paths):
        if not metadata_path.endswith("_metadata"):
            continue
        try:
            with upload_folder.get_download_stream(metadata_path) as stream:
                metadata = json.loads(stream.read().decode("utf-8-sig"))
            md5_hash = str(metadata.get("source_file_md5") or "").lower()
            if not md5_hash:
                continue
            stored_path = str(
                metadata.get("stored_path") or metadata_path[:-9]
            )
            path_parts = stored_path.strip("/").split("/", 1)
            upload_date = path_parts[0] if len(path_parts) == 2 else ""
            index.setdefault(md5_hash, []).append({
                "stored_path": stored_path,
                "metadata_path": metadata_path,
                "upload_date": upload_date,
                "uploaded_at_gmt8": metadata.get("uploaded_at_gmt8"),
            })
        except Exception:
            # Invalid metadata is handled by the downstream integrity checks;
            # it must not prevent unrelated files from being uploaded.
            continue
    return index


def choose_target_filename(
    original_filename, upload_date, existing_paths, force_numbered_copy=False
):
    exact_path = "/{}/{}".format(upload_date, original_filename)
    exact_metadata_path = exact_path + "_metadata"
    if (
        not force_numbered_copy
        and exact_path not in existing_paths
        and exact_metadata_path not in existing_paths
    ):
        return original_filename, False

    stem, extension = os.path.splitext(original_filename)
    numbered_stem = re.fullmatch(r"(.*) \((\d+)\)", stem)
    if numbered_stem:
        base_stem = numbered_stem.group(1)
        copy_number = int(numbered_stem.group(2)) + 1
    else:
        base_stem = stem
        copy_number = 1
    while True:
        candidate = "{} ({}){}".format(base_stem, copy_number, extension)
        candidate_path = "/{}/{}".format(upload_date, candidate)
        if (
            candidate_path not in existing_paths
            and candidate_path + "_metadata" not in existing_paths
        ):
            return candidate, True
        copy_number += 1


def store_file(
    original_filename,
    raw_bytes,
    source_file_md5,
    source_system,
    upload_date,
    source_record_date,
    uploaded_by,
    existing_paths,
    ingestion_action="new_upload",
    duplicate_reference_paths=None,
    force_numbered_copy=False,
):
    file_size_bytes = len(raw_bytes)

    uploaded_at = datetime.now(GMT_PLUS_8)
    stored_filename, numbered_copy = choose_target_filename(
        original_filename=original_filename,
        upload_date=upload_date,
        existing_paths=existing_paths,
        force_numbered_copy=force_numbered_copy,
    )
    target_path = "/{}/{}".format(upload_date, stored_filename)
    metadata_path = target_path + "_metadata"

    upload_folder.upload_stream(target_path, io.BytesIO(raw_bytes))

    metadata = {
        "metadata_version": "3.1",
        "source_file_md5": source_file_md5,
        "source_file_reference": "md5:{}".format(source_file_md5),
        "source_record_date": source_record_date,
        "source_record_date_origin": (
            "user_input" if source_record_date else "pending_source_extraction"
        ),
        "uploaded_at_gmt8": uploaded_at.isoformat(),
        "upload_timezone": "GMT+8",
        "uploaded_by": uploaded_by,
        "original_file_name": original_filename,
        "stored_file_name": stored_filename,
        "stored_path": target_path,
        "metadata_path": metadata_path,
        "ingestion_action": (
            "filename_collision_copy"
            if ingestion_action == "new_upload" and numbered_copy
            else ingestion_action
        ),
        "duplicate_reference_paths": duplicate_reference_paths or [],
        "source_system": str(source_system or "").strip()[:100],
        "file_size_bytes": file_size_bytes,
    }

    upload_folder.upload_stream(
        metadata_path,
        io.BytesIO(
            json.dumps(metadata, ensure_ascii=False, indent=2).encode("utf-8")
        ),
    )

    existing_paths.add(target_path)
    existing_paths.add(metadata_path)

    return metadata


def result_card(filename, success, detail):
    color = COLORS["success"] if success else COLORS["danger"]
    background = COLORS["success_soft"] if success else COLORS["danger_soft"]
    label = "Uploaded" if success else "Failed"

    return html.Div(
        [
            html.Div(filename, style={"fontWeight": "700", "overflowWrap": "anywhere"}),
            html.Div(
                "{} · {}".format(label, detail),
                style={"color": color, "fontSize": "13px", "marginTop": "4px"},
            ),
        ],
        style={
            "padding": "13px 14px",
            "background": background,
            "border": "1px solid {}".format(color),
            "borderRadius": "10px",
            "marginBottom": "9px",
        },
    )


def confirmation_panel_style(visible, has_duplicates=False):
    return {
        "display": "block" if visible else "none",
        "marginTop": "18px",
        "padding": "16px",
        "background": "#fff8e6" if has_duplicates else COLORS["primary_soft"],
        "border": "1px solid {}".format(
            "#e0a800" if has_duplicates else COLORS["primary"]
        ),
        "borderRadius": "10px",
    }


def upload_summary(
    successful,
    requested,
    upload_date,
    source_record_date,
    uploaded_by,
    upload_started_at,
    pending_count=0,
):
    summary_color = (
        COLORS["success"]
        if successful == requested and pending_count == 0
        else COLORS["primary"]
    )
    primary_text = "{} of {} file(s) uploaded. Directory: {}".format(
        successful, requested, upload_date
    )
    if pending_count:
        primary_text += " · {} file(s) awaiting confirmation".format(
            pending_count
        )

    return html.Div(
        [
            html.Div(primary_text),
            html.Div(
                "Record date: {} · Uploaded by: {} · Uploaded at: {}".format(
                    source_record_date or "Pending source extraction",
                    uploaded_by,
                    upload_started_at.strftime("%Y-%m-%d %H:%M:%S GMT+8"),
                ),
                style={"fontSize": "13px", "marginTop": "4px"},
            ),
        ],
        style={
            "color": summary_color,
            "fontWeight": "750",
            "marginBottom": "12px",
        },
    )


def build_upload_prompt(items):
    rows = []
    for item in items:
        dates = sorted(
            set(match.get("upload_date") or "unknown" for match in item["matches"])
        )
        if item["duplicate_scope"] == "none":
            detail = "Ready to upload. No matching MD5 was found."
        elif item["duplicate_scope"] == "pending_selection":
            detail = (
                "Identical content is already in this pending selection. "
                "If confirmed, the additional copy will use a numbered filename."
            )
        elif item["duplicate_scope"] == "same_day":
            detail = (
                "Identical content already exists today. If continued, a "
                "numbered copy such as file (1).csv will be created."
            )
        else:
            detail = (
                "Identical content was uploaded on {}. Continue only if it "
                "should be re-ingested into today's folder."
            ).format(", ".join(dates))
        rows.append(
            html.Li(
                [
                    html.Strong(item["filename"]),
                    html.Div(
                        detail,
                        style={"color": COLORS["muted"], "marginTop": "3px"},
                    ),
                ],
                style={"marginBottom": "10px"},
            )
        )

    return [
        html.Div(
            "Review upload · {} file(s) selected".format(len(items)),
            style={"fontWeight": "800", "color": COLORS["ink"]},
        ),
        html.Ul(rows, style={"paddingLeft": "20px", "marginBottom": "0"}),
    ]


app.title = "Raw File Upload Portal"

app.layout = html.Div(
    html.Div(
        [
            html.Div(
                "DATA INGESTION",
                style={
                    "color": COLORS["primary"],
                    "fontSize": "12px",
                    "fontWeight": "800",
                    "letterSpacing": "0.12em",
                    "marginBottom": "8px",
                },
            ),
            html.H1(
                "Upload source files",
                style={
                    "color": COLORS["ink"],
                    "fontSize": "36px",
                    "letterSpacing": "-0.035em",
                    "margin": "0 0 10px",
                },
            ),
            html.P(
                "Add CSV, TSV, or TXT files for schema profiling and standardized processing.",
                style={
                    "color": COLORS["muted"],
                    "lineHeight": "1.55",
                    "margin": "0 0 28px",
                },
            ),
            html.Label(
                ["Source system ", html.Span("optional", style={"color": COLORS["muted"], "fontWeight": "400"})],
                htmlFor="source-system",
                style={"display": "block", "fontWeight": "700", "marginBottom": "4px"},
            ),
            html.Div(
                "Identify where these files came from, for example CRM, HR, Billing, or Vendor A. This is recorded as upload metadata.",
                style={
                    "color": COLORS["muted"],
                    "fontSize": "13px",
                    "lineHeight": "20px",
                    "marginBottom": "8px",
                },
            ),
            dcc.Input(
                id="source-system",
                type="text",
                maxLength=100,
                placeholder="Example: CRM export",
                style={
                    "width": "100%",
                    "height": "52px",
                    "padding": "0 16px",
                    "color": COLORS["ink"],
                    "backgroundColor": COLORS["surface"],
                    "WebkitTextFillColor": COLORS["ink"],
                    "fontSize": "16px",
                    "fontWeight": "400",
                    "lineHeight": "24px",
                    "opacity": "1",
                    "border": "1px solid {}".format(COLORS["line"]),
                    "borderRadius": "9px",
                    "marginBottom": "20px",
                    "boxSizing": "border-box",
                },
            ),
            html.Label(
                [
                    "Source record date ",
                    html.Span(
                        "optional",
                        style={"color": COLORS["muted"], "fontWeight": "400"},
                    ),
                ],
                htmlFor="record-date",
                style={
                    "display": "block",
                    "fontWeight": "700",
                    "marginBottom": "4px",
                },
            ),
            html.Div(
                "Enter the business-effective date represented by these files. Leave it empty when the date should be extracted from each source file later in the pipeline.",
                style={
                    "color": COLORS["muted"],
                    "fontSize": "13px",
                    "lineHeight": "20px",
                    "marginBottom": "8px",
                },
            ),
            dcc.Input(
                id="record-date",
                type="date",
                style={
                    "width": "100%",
                    "height": "52px",
                    "padding": "0 16px",
                    "color": COLORS["ink"],
                    "backgroundColor": COLORS["surface"],
                    "WebkitTextFillColor": COLORS["ink"],
                    "fontSize": "16px",
                    "fontWeight": "400",
                    "lineHeight": "24px",
                    "opacity": "1",
                    "border": "1px solid {}".format(COLORS["line"]),
                    "borderRadius": "9px",
                    "marginBottom": "20px",
                    "boxSizing": "border-box",
                },
            ),
            dcc.Upload(
                id="upload-data",
                children=html.Div(
                    [
                        html.Div(
                            "⇧",
                            style={
                                "display": "inline-grid",
                                "placeItems": "center",
                                "width": "46px",
                                "height": "46px",
                                "color": COLORS["primary"],
                                "background": COLORS["primary_soft"],
                                "borderRadius": "50%",
                                "fontSize": "28px",
                                "fontWeight": "800",
                                "marginBottom": "10px",
                            },
                        ),
                        html.Div(
                            "Drop files here — repeat to add more",
                            style={"fontWeight": "750"},
                        ),
                        html.Div(
                            "or click to add files to the pending selection",
                            style={"color": COLORS["muted"], "marginTop": "4px"},
                        ),
                        html.Small(
                            "Multiple drops are accumulated · CSV, TSV, or TXT · maximum {} MB per file".format(MAX_FILE_SIZE_MB),
                            style={"display": "block", "color": COLORS["muted"], "marginTop": "8px"},
                        ),
                    ]
                ),
                accept=".csv,.tsv,.txt",
                multiple=True,
                disable_click=False,
                max_size=MAX_FILE_SIZE_BYTES,
                style={
                    "width": "100%",
                    "minHeight": "220px",
                    "display": "grid",
                    "placeItems": "center",
                    "textAlign": "center",
                    "background": "#fafcff",
                    "border": "2px dashed #aab9d2",
                    "borderRadius": "15px",
                    "cursor": "pointer",
                    "padding": "28px",
                    "boxSizing": "border-box",
                },
            ),
            dcc.Store(id="pending-upload", storage_type="memory"),
            html.Div(
                [
                    html.Div(id="confirmation-summary"),
                    html.Div(
                        [
                            html.Button(
                                "Confirm upload",
                                id="confirm-upload",
                                n_clicks=0,
                                style={
                                    "border": "0",
                                    "borderRadius": "8px",
                                    "padding": "11px 16px",
                                    "background": COLORS["primary"],
                                    "color": "#ffffff",
                                    "fontWeight": "700",
                                    "cursor": "pointer",
                                    "marginRight": "10px",
                                },
                            ),
                            html.Button(
                                "Cancel upload",
                                id="cancel-upload",
                                n_clicks=0,
                                style={
                                    "border": "1px solid {}".format(COLORS["line"]),
                                    "borderRadius": "8px",
                                    "padding": "10px 16px",
                                    "background": COLORS["surface"],
                                    "color": COLORS["ink"],
                                    "fontWeight": "700",
                                    "cursor": "pointer",
                                },
                            ),
                        ],
                        style={"marginTop": "14px"},
                    ),
                ],
                id="confirmation-panel",
                style={
                    "display": "none",
                    "marginTop": "18px",
                    "padding": "16px",
                    "background": "#fff8e6",
                    "border": "1px solid #e0a800",
                    "borderRadius": "10px",
                },
            ),
            dcc.Loading(
                type="circle",
                color=COLORS["primary"],
                children=html.Div(id="upload-results", style={"marginTop": "22px"}),
            ),
        ],
        style={
            "width": "min(760px, 100%)",
            "padding": "36px",
            "background": COLORS["surface"],
            "border": "1px solid {}".format(COLORS["line"]),
            "borderRadius": "20px",
            "boxShadow": "0 20px 55px rgba(19, 33, 68, 0.12)",
            "boxSizing": "border-box",
        },
    ),
    style={
        "minHeight": "100vh",
        "display": "grid",
        "placeItems": "start center",
        "padding": "48px 20px",
        "background": COLORS["canvas"],
        "fontFamily": "Inter, system-ui, -apple-system, Segoe UI, sans-serif",
        "boxSizing": "border-box",
    },
)


@app.callback(
    Output("upload-results", "children"),
    Output("pending-upload", "data"),
    Output("confirmation-panel", "style"),
    Output("confirmation-summary", "children"),
    Input("upload-data", "contents"),
    Input("confirm-upload", "n_clicks"),
    Input("cancel-upload", "n_clicks"),
    State("upload-data", "filename"),
    State("source-system", "value"),
    State("record-date", "value"),
    State("pending-upload", "data"),
    prevent_initial_call=True,
)
def upload_files(
    uploaded_contents,
    confirm_clicks,
    cancel_clicks,
    uploaded_filenames,
    source_system,
    record_date,
    pending_data,
):
    del confirm_clicks, cancel_clicks
    triggered_id = callback_context.triggered[0]["prop_id"].split(".")[0]

    if triggered_id == "cancel-upload":
        if not pending_data:
            raise PreventUpdate
        file_count = len(pending_data.get("items", []))
        message = html.Div(
            "Upload cancelled. No files were written. {} file(s) were removed "
            "from the pending review.".format(file_count),
            style={
                "padding": "13px 14px",
                "background": COLORS["primary_soft"],
                "border": "1px solid {}".format(COLORS["primary"]),
                "borderRadius": "10px",
                "color": COLORS["primary"],
                "fontWeight": "700",
            },
        )
        return message, None, confirmation_panel_style(False), []

    if triggered_id == "upload-data":
        if isinstance(uploaded_contents, str):
            uploaded_contents = [uploaded_contents]
        if isinstance(uploaded_filenames, str):
            uploaded_filenames = [uploaded_filenames]

        if not uploaded_contents or not uploaded_filenames:
            raise PreventUpdate

        if len(uploaded_contents) != len(uploaded_filenames):
            return (
                result_card(
                    "Upload",
                    False,
                    "The browser returned mismatched file metadata.",
                ),
                pending_data,
                confirmation_panel_style(bool(pending_data)),
                build_upload_prompt(pending_data.get("items", []))
                if pending_data
                else [],
            )
    elif triggered_id == "confirm-upload":
        if not pending_data or not pending_data.get("items"):
            raise PreventUpdate
    else:
        raise PreventUpdate

    try:
        source_record_date = normalize_record_date(record_date)
        uploaded_by = get_authenticated_uploader()
    except Exception as error:
        return (
            result_card("Upload", False, str(error)),
            pending_data,
            confirmation_panel_style(bool(pending_data)),
            build_upload_prompt(pending_data.get("items", []))
            if pending_data
            else [],
        )

    upload_started_at = datetime.now(GMT_PLUS_8)
    upload_date = upload_started_at.strftime("%Y-%m-%d")
    existing_paths = set(upload_folder.list_paths_in_partition())
    md5_index = build_md5_index(existing_paths)

    if triggered_id == "confirm-upload":
        cards = []
        uploaded_files = []
        for item in pending_data["items"]:
            try:
                filename = item["filename"]
                contents = item["contents"]
                raw_bytes, source_file_md5 = prepare_upload(filename, contents)
                if source_file_md5 != item["source_file_md5"]:
                    raise ValueError(
                        "The selected file changed after duplicate review. "
                        "Select the files again."
                    )

                matches = md5_index.get(source_file_md5, [])
                has_same_day_match = any(
                    match.get("upload_date") == upload_date for match in matches
                )
                if has_same_day_match:
                    ingestion_action = "same_day_reupload"
                elif matches:
                    ingestion_action = "different_day_reingest"
                else:
                    ingestion_action = "new_upload"
                metadata = store_file(
                    original_filename=filename,
                    raw_bytes=raw_bytes,
                    source_file_md5=source_file_md5,
                    source_system=source_system,
                    upload_date=upload_date,
                    source_record_date=source_record_date,
                    uploaded_by=uploaded_by,
                    existing_paths=existing_paths,
                    ingestion_action=ingestion_action,
                    duplicate_reference_paths=[
                        match["stored_path"] for match in matches
                    ],
                    force_numbered_copy=has_same_day_match,
                )
                uploaded_files.append(metadata)
                md5_index.setdefault(source_file_md5, []).append({
                    "stored_path": metadata["stored_path"],
                    "metadata_path": metadata["metadata_path"],
                    "upload_date": upload_date,
                    "uploaded_at_gmt8": metadata["uploaded_at_gmt8"],
                })
                cards.append(
                    result_card(
                        filename,
                        True,
                        "{} as {} · {:.1f} MB".format(
                            {
                                "same_day_reupload": "Re-uploaded",
                                "different_day_reingest": "Re-ingested",
                                "new_upload": "Uploaded",
                            }[ingestion_action],
                            metadata["stored_file_name"],
                            metadata["file_size_bytes"] / 1024 / 1024,
                        ),
                    )
                )
            except Exception as error:
                cards.append(result_card(item.get("filename", "File"), False, str(error)))

        summary = upload_summary(
            successful=len(uploaded_files),
            requested=len(pending_data["items"]),
            upload_date=upload_date,
            source_record_date=source_record_date,
            uploaded_by=uploaded_by,
            upload_started_at=upload_started_at,
        )
        return [summary] + cards, None, confirmation_panel_style(False), []

    if triggered_id != "upload-data":
        raise PreventUpdate

    cards = []
    pending_items = list((pending_data or {}).get("items", []))
    pending_hashes = {
        item.get("source_file_md5") for item in pending_items
    }
    invalid_count = 0

    for filename, contents in zip(uploaded_filenames, uploaded_contents):
        try:
            raw_bytes, source_file_md5 = prepare_upload(filename, contents)
            matches = md5_index.get(source_file_md5, [])
            has_same_day_match = any(
                match.get("upload_date") == upload_date for match in matches
            )
            pending_items.append({
                "filename": filename,
                "contents": contents,
                "source_file_md5": source_file_md5,
                "file_size_bytes": len(raw_bytes),
                "duplicate_scope": (
                    "same_day"
                    if has_same_day_match
                    else "different_day"
                    if matches
                    else "pending_selection"
                    if source_file_md5 in pending_hashes
                    else "none"
                ),
                "matches": matches,
            })
            pending_hashes.add(source_file_md5)
        except Exception as error:
            invalid_count += 1
            cards.append(result_card(filename, False, str(error)))

    summary = upload_summary(
        successful=0,
        requested=len(pending_items) + invalid_count,
        upload_date=upload_date,
        source_record_date=source_record_date,
        uploaded_by=uploaded_by,
        upload_started_at=upload_started_at,
        pending_count=len(pending_items),
    )

    if not pending_items:
        return [summary] + cards, None, confirmation_panel_style(False), []

    pending_payload = {
        "items": pending_items,
        "detected_at_gmt8": (pending_data or {}).get(
            "detected_at_gmt8", upload_started_at.isoformat()
        ),
    }
    has_duplicates = any(
        item["duplicate_scope"] != "none" for item in pending_items
    )
    return (
        [summary] + cards,
        pending_payload,
        confirmation_panel_style(True, has_duplicates=has_duplicates),
        build_upload_prompt(pending_items),
    )
