"""Dash administration portal for the DATA_INJESTION project.

Dataiku creates the Dash ``app`` object. Paste this file into the Python tab of
an Empty Dash webapp; do not add ``app = Dash(...)``.
"""

import hashlib
import json
import threading
import uuid
from datetime import datetime, timedelta, timezone

import dataiku
import pandas as pd
from dash import Input, Output, State, callback_context, dash_table, dcc, html
from dash.exceptions import PreventUpdate
from flask import request


PROPOSALS_DATASET = "Schema-Proposal"
CATALOG_DATASET = "Schema-Mapping-Catalog"
STANDARD_DATASET = "DATA_STANDARDS.Column-Standard"
CLEANING_STANDARD_DATASET = "DATA_STANDARDS.Cleaning-Standard"
PREPARE_SCENARIO_DEFAULT = "PREPARE_INGESTION_MAPPINGS"

GMT_PLUS_8 = timezone(timedelta(hours=8), name="GMT+8")
CATALOG_WRITE_LOCK = threading.Lock()

api_client = dataiku.api_client()
project = api_client.get_default_project()


COLORS = {
    "ink": "#172033",
    "muted": "#667085",
    "line": "#d9e0ea",
    "surface": "#ffffff",
    "canvas": "#f3f6fa",
    "primary": "#2457d6",
    "primary_soft": "#edf3ff",
    "success": "#087a55",
    "success_soft": "#eaf8f2",
    "warning": "#9a6700",
    "warning_soft": "#fff8e6",
    "danger": "#b42318",
    "danger_soft": "#fff0ee",
}


def text_value(value):
    if value is None or pd.isna(value):
        return ""
    return str(value)


def bool_value(value):
    if isinstance(value, bool):
        return value
    return text_value(value).strip().lower() in {"true", "1", "yes"}


def float_value(value, default=0.0):
    try:
        if value is None or pd.isna(value):
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def int_value(value, default=0):
    try:
        if value is None or pd.isna(value):
            return default
        return int(value)
    except (TypeError, ValueError):
        return default


def json_value(value, expected_type, default):
    if isinstance(value, expected_type):
        return value
    if value is None or text_value(value).strip() == "":
        return default
    try:
        parsed = json.loads(text_value(value))
    except (TypeError, ValueError):
        return default
    return parsed if isinstance(parsed, expected_type) else default


def get_authenticated_user():
    auth_info = api_client.get_auth_info_from_browser_headers(
        dict(request.headers)
    )
    username = auth_info.get("associatedDSSUser") or auth_info.get(
        "authIdentifier"
    )
    if not username:
        raise ValueError("The authenticated Dataiku user could not be identified.")
    return str(username)


def scenario_id_from_variable(variable_name, default_value):
    """Read scenario IDs at callback time and reject null-like values."""
    current_variables = dataiku.get_custom_variables()
    raw_value = current_variables.get(variable_name)
    value = "" if raw_value is None else str(raw_value).strip()
    if value.lower() in {"", "none", "null"}:
        return default_value
    return value


def same_project_dataset(name):
    return dataiku.Dataset(name, ignore_flow=True)


def dataset_from_reference(reference):
    """Open a local name or a shared Dataiku smart name."""
    return dataiku.Dataset(reference, ignore_flow=True)


def load_standards():
    dataset = dataset_from_reference(STANDARD_DATASET)
    standards = {}
    versions = set()
    for row in dataset.iter_rows():
        standard_name = text_value(row.get("standard_name")).strip()
        if not standard_name:
            continue
        version = text_value(row.get("version")).strip()
        versions.add(version)
        standards[standard_name] = {
            "standard_name": standard_name,
            "version": version,
            "semantic_type": text_value(row.get("semantic_type")),
            "spark_type": text_value(row.get("spark_type")),
            "nullable": bool_value(row.get("nullable")),
            "target_format": json_value(
                row.get("target_format"), dict, {}
            ),
            "cleaning_rule_id": text_value(row.get("cleaning_rule_id")),
            "validation_rule_id": text_value(
                row.get("validation_rule_id")
            ),
        }

    if not standards or "others" not in standards:
        raise ValueError(
            "Column-Standard must contain approved columns and the others fallback."
        )
    if len(versions) != 1 or "" in versions:
        raise ValueError("Column-Standard must contain exactly one non-empty version.")
    return standards, next(iter(versions))


def load_cleaning_standard_version():
    dataset = dataset_from_reference(CLEANING_STANDARD_DATASET)
    versions = {
        text_value(row.get("version")).strip()
        for row in dataset.iter_rows()
    }
    if len(versions) != 1 or "" in versions:
        raise ValueError(
            "Cleaning-Standard must contain exactly one non-empty version."
        )
    return next(iter(versions))


def proposal_mapping_id(row):
    contract_version = text_value(row.get("column_contract_version"))
    cleaning_version = text_value(row.get("cleaning_standard_version"))
    ordered_fingerprint = text_value(row.get("ordered_schema_fingerprint"))
    if not contract_version or not cleaning_version or not ordered_fingerprint:
        return ""
    raw_key = "{}:{}:{}".format(
        contract_version,
        cleaning_version,
        ordered_fingerprint,
    )
    return "MAP-{}".format(
        hashlib.sha256(raw_key.encode("utf-8")).hexdigest()[:24]
    )


def read_catalog():
    try:
        return same_project_dataset(CATALOG_DATASET).get_dataframe()
    except Exception:
        return pd.DataFrame()


def latest_catalog_decisions(catalog_df):
    if catalog_df.empty or "mapping_id" not in catalog_df.columns:
        return {}

    rows = catalog_df.to_dict("records")
    rows.sort(
        key=lambda row: (
            text_value(row.get("reviewed_at_utc")),
            text_value(row.get("decision_id")),
        )
    )
    return {
        text_value(row.get("mapping_id")): row
        for row in rows
        if text_value(row.get("mapping_id"))
    }


def read_proposals():
    return same_project_dataset(PROPOSALS_DATASET).get_dataframe()


def proposal_status(row, latest_decisions):
    if text_value(row.get("understanding_status")).upper() != "SUCCESS":
        return "ERROR"
    mapping_id = proposal_mapping_id(row)
    decision = latest_decisions.get(mapping_id, {})
    decision_name = text_value(decision.get("decision")).upper()
    if decision_name in {"APPROVED", "REJECTED"}:
        return decision_name
    if bool_value(row.get("requires_human_review")):
        return "REVIEW"
    return "PENDING"


def dashboard_records(status_filter="ALL", search_text=""):
    proposals_df = read_proposals()
    latest = latest_catalog_decisions(read_catalog())
    records = []

    for row in proposals_df.to_dict("records"):
        status = proposal_status(row, latest)
        record = {
            "mapping_id": proposal_mapping_id(row),
            "status": status,
            "file_name": text_value(row.get("file_name")),
            "source_system": text_value(row.get("source_system")),
            "uploaded_by": text_value(row.get("uploaded_by")),
            "uploaded_at_gmt8": text_value(row.get("uploaded_at_gmt8")),
            "confidence": float_value(row.get("overall_confidence")),
            "mapped": int_value(row.get("mapped_column_count")),
            "review": int_value(row.get("review_column_count")),
            "others": int_value(row.get("other_column_count")),
            "sample_fingerprint": text_value(row.get("sample_fingerprint")),
        }
        records.append(record)

    search_term = text_value(search_text).strip().lower()
    if status_filter and status_filter != "ALL":
        records = [
            record for record in records if record["status"] == status_filter
        ]
    if search_term:
        records = [
            record
            for record in records
            if search_term
            in " ".join(
                [
                    record["file_name"],
                    record["source_system"],
                    record["uploaded_by"],
                    record["mapping_id"],
                ]
            ).lower()
        ]
    records.sort(key=lambda row: row["uploaded_at_gmt8"], reverse=True)
    return records


def find_proposal(mapping_id, sample_fingerprint=""):
    matches = []
    for row in read_proposals().to_dict("records"):
        if proposal_mapping_id(row) != mapping_id:
            continue
        if sample_fingerprint and text_value(
            row.get("sample_fingerprint")
        ) != sample_fingerprint:
            continue
        matches.append(row)
    if not matches:
        raise ValueError("The selected proposal is no longer available.")
    matches.sort(
        key=lambda row: text_value(row.get("understanding_generated_at_utc")),
        reverse=True,
    )
    return matches[0]


def editor_rows(proposal):
    mappings = json_value(proposal.get("column_mappings_json"), list, [])
    return [
        {
            "source_position": int(mapping.get("source_position") or 0),
            "source_name": text_value(mapping.get("source_name")),
            "inferred_meaning": text_value(mapping.get("inferred_meaning")),
            "suggested_standard_name": text_value(
                mapping.get("suggested_standard_name") or "others"
            ),
            "detected_source_format": text_value(
                mapping.get("detected_source_format")
            ),
            "confidence": float_value(mapping.get("confidence")),
            "reason": text_value(mapping.get("reason")),
        }
        for mapping in mappings
    ]


def decision_banner(message, kind="success"):
    color = COLORS.get(kind, COLORS["ink"])
    background = COLORS.get("{}_soft".format(kind), COLORS["surface"])
    return html.Div(
        message,
        style={
            "padding": "12px 14px",
            "border": "1px solid {}".format(color),
            "background": background,
            "color": color,
            "borderRadius": "9px",
            "fontWeight": "700",
            "marginTop": "12px",
        },
    )


def prepare_reviewed_mappings(
    proposal, edited_rows, standards, enforce_approval_rules=True
):
    original = editor_rows(proposal)
    original_by_position = {
        row["source_position"]: row for row in original
    }
    if len(edited_rows or []) != len(original):
        raise ValueError("The reviewed mapping must contain every source column.")

    reviewed = []
    used_targets = {}
    for edited in edited_rows:
        try:
            position = int(edited.get("source_position"))
        except (TypeError, ValueError):
            raise ValueError("A source column has an invalid position.")

        source = original_by_position.get(position)
        if not source or text_value(edited.get("source_name")) != source["source_name"]:
            raise ValueError("Source column names or positions cannot be changed.")

        standard_name = text_value(
            edited.get("suggested_standard_name")
        ).strip()
        if standard_name not in standards:
            raise ValueError(
                "{} is not an approved standard column.".format(standard_name)
            )

        if enforce_approval_rules and standard_name != "others":
            if standard_name in used_targets:
                raise ValueError(
                    "Source columns {} and {} both map to {}. Select one or "
                    "map the other to others.".format(
                        used_targets[standard_name], position, standard_name
                    )
                )
            used_targets[standard_name] = position

        source_format = text_value(
            edited.get("detected_source_format")
        ).strip()
        standard = standards[standard_name]
        if (
            enforce_approval_rules
            and standard["spark_type"] in {"date", "timestamp", "timestamp_ntz"}
        ):
            if not source_format:
                raise ValueError(
                    "Enter the detected source format for {} before approval."
                    .format(source["source_name"])
                )

        reviewed.append({
            "source_position": position,
            "source_name": source["source_name"],
            "inferred_meaning": source["inferred_meaning"],
            "suggested_standard_name": standard_name,
            "mapping_status": (
                "OTHER" if standard_name == "others" else "MAPPED"
            ),
            "detected_source_format": source_format,
            "confidence": source["confidence"],
            "reason": source["reason"],
            "target_semantic_type": standard["semantic_type"],
            "target_spark_type": standard["spark_type"],
            "target_nullable": standard["nullable"],
            "target_format": standard["target_format"],
            "cleaning_rule_id": standard["cleaning_rule_id"],
            "validation_rule_id": standard["validation_rule_id"],
        })

    reviewed.sort(key=lambda row: row["source_position"])
    return reviewed


def append_catalog_decision(proposal, reviewed_mappings, decision, note, user):
    now_utc = datetime.now(timezone.utc)
    mapping_id = proposal_mapping_id(proposal)
    if not mapping_id:
        raise ValueError("The proposal has no reusable schema fingerprint.")

    proposal_snapshot = {
        "proposal_json": json_value(proposal.get("proposal_json"), dict, {}),
        "review_reasons": json_value(
            proposal.get("review_reasons_json"), list, []
        ),
        "understanding_generated_at_utc": text_value(
            proposal.get("understanding_generated_at_utc")
        ),
    }
    event = {
        "decision_id": str(uuid.uuid4()),
        "mapping_id": mapping_id,
        "decision": decision,
        "approval_scope": "EXACT_ORDERED_SCHEMA",
        "reviewed_at_utc": now_utc.isoformat(),
        "reviewed_at_gmt8": now_utc.astimezone(GMT_PLUS_8).isoformat(),
        "reviewed_by": user,
        "review_note": text_value(note).strip()[:2000],
        "file_name": text_value(proposal.get("file_name")),
        "file_path": text_value(proposal.get("file_path")),
        "source_file_md5": text_value(proposal.get("source_file_md5")),
        "source_system": text_value(proposal.get("source_system")),
        "column_contract_version": text_value(
            proposal.get("column_contract_version")
        ),
        "cleaning_standard_version": text_value(
            proposal.get("cleaning_standard_version")
        ),
        "ordered_schema_fingerprint": text_value(
            proposal.get("ordered_schema_fingerprint")
        ),
        "column_set_fingerprint": text_value(
            proposal.get("column_set_fingerprint")
        ),
        "sample_fingerprint": text_value(proposal.get("sample_fingerprint")),
        "prompt_version": text_value(proposal.get("prompt_version")),
        "llm_id": text_value(proposal.get("llm_id")),
        "overall_confidence": float_value(proposal.get("overall_confidence")),
        "reviewed_column_count": len(reviewed_mappings),
        "reviewed_mappings_json": json.dumps(
            reviewed_mappings, ensure_ascii=False, separators=(",", ":")
        ),
        "proposal_snapshot_json": json.dumps(
            proposal_snapshot, ensure_ascii=False, separators=(",", ":")
        ),
    }

    event_df = pd.DataFrame([event])
    with CATALOG_WRITE_LOCK:
        catalog = same_project_dataset(CATALOG_DATASET)
        catalog.spec_item["appendMode"] = True
        catalog.write_with_schema(event_df)
    return event


def scenario_summary(scenario_id):
    try:
        scenario = project.get_scenario(scenario_id)
        current = scenario.get_current_run()
        if current is not None and current.running:
            return "RUNNING", "Started {}".format(
                current.start_time.astimezone(GMT_PLUS_8).strftime(
                    "%Y-%m-%d %H:%M:%S GMT+8"
                )
            )
        runs = scenario.get_last_runs(limit=1)
        if not runs:
            return "NOT RUN", "No previous run"
        last = runs[0]
        outcome = text_value(last.outcome or "UNKNOWN")
        started = last.start_time.astimezone(GMT_PLUS_8).strftime(
            "%Y-%m-%d %H:%M:%S GMT+8"
        )
        return outcome, "Last run started {}".format(started)
    except Exception as error:
        return "UNAVAILABLE", str(error)[:300]


def status_pill(status, detail):
    color = COLORS["muted"]
    background = COLORS["canvas"]
    if status in {"SUCCESS", "APPROVED"}:
        color, background = COLORS["success"], COLORS["success_soft"]
    elif status in {"FAILED", "ABORTED", "ERROR", "UNAVAILABLE"}:
        color, background = COLORS["danger"], COLORS["danger_soft"]
    elif status in {"RUNNING", "WARNING", "REVIEW"}:
        color, background = COLORS["warning"], COLORS["warning_soft"]
    return html.Div(
        [
            html.Div(status, style={"fontWeight": "800"}),
            html.Div(detail, style={"fontSize": "12px", "marginTop": "3px"}),
        ],
        style={
            "color": color,
            "background": background,
            "border": "1px solid {}".format(color),
            "borderRadius": "9px",
            "padding": "10px 12px",
            "marginTop": "10px",
        },
    )


def summary_card(label, value, color):
    return html.Div(
        [
            html.Div(label, style={"color": COLORS["muted"], "fontSize": "12px"}),
            html.Div(
                str(value),
                style={"fontSize": "26px", "fontWeight": "800", "color": color},
            ),
        ],
        style={
            "background": COLORS["surface"],
            "border": "1px solid {}".format(COLORS["line"]),
            "borderRadius": "12px",
            "padding": "14px 16px",
        },
    )


BUTTON_STYLE = {
    "border": "0",
    "borderRadius": "8px",
    "padding": "11px 15px",
    "background": COLORS["primary"],
    "color": "#ffffff",
    "fontWeight": "750",
    "cursor": "pointer",
}

CARD_STYLE = {
    "background": COLORS["surface"],
    "border": "1px solid {}".format(COLORS["line"]),
    "borderRadius": "14px",
    "padding": "20px",
}


app.title = "Data Ingestion Administration"

app.layout = html.Div(
    [
        dcc.Interval(id="status-poll", interval=5000, n_intervals=0),
        dcc.Store(id="selected-proposal", storage_type="memory"),
        dcc.Store(id="approval-event", storage_type="memory"),
        html.Div(
            [
                html.Div(
                    "DATA ADMINISTRATION",
                    style={
                        "color": COLORS["primary"],
                        "fontWeight": "800",
                        "fontSize": "12px",
                        "letterSpacing": "0.12em",
                    },
                ),
                html.H1(
                    "Ingestion control centre",
                    style={"margin": "7px 0 5px", "color": COLORS["ink"]},
                ),
                html.Div(
                    "Prepare LLM column mappings, review them, and record auditable decisions.",
                    style={"color": COLORS["muted"]},
                ),
            ],
            style={"marginBottom": "22px"},
        ),
        html.Div(
            [
                html.H3("1 · Prepare mappings", style={"marginTop": "0"}),
                html.P(
                    "Copy raw files to staging, sample columns, and generate mapping proposals.",
                    style={"color": COLORS["muted"]},
                ),
                html.Button(
                    "Run prepare flow",
                    id="run-prepare",
                    n_clicks=0,
                    style=BUTTON_STYLE,
                ),
                html.Div(id="prepare-status"),
            ],
            style={**CARD_STYLE, "marginBottom": "16px"},
        ),
        html.Div(id="scenario-message"),
        html.Div(id="summary-cards", style={"margin": "16px 0"}),
        html.Div(
            [
                html.Div(
                    [
                        html.H2("2 · Review mappings", style={"margin": "0"}),
                        html.Button(
                            "Refresh",
                            id="refresh-proposals",
                            n_clicks=0,
                            style={**BUTTON_STYLE, "background": COLORS["ink"]},
                        ),
                    ],
                    style={
                        "display": "flex",
                        "justifyContent": "space-between",
                        "alignItems": "center",
                        "gap": "12px",
                    },
                ),
                html.Div(
                    [
                        dcc.Dropdown(
                            id="status-filter",
                            options=[
                                {"label": "All statuses", "value": "ALL"},
                                {"label": "Needs review", "value": "REVIEW"},
                                {"label": "Pending confirmation", "value": "PENDING"},
                                {"label": "Approved", "value": "APPROVED"},
                                {"label": "Rejected", "value": "REJECTED"},
                                {"label": "Errors", "value": "ERROR"},
                            ],
                            value="ALL",
                            clearable=False,
                        ),
                        dcc.Input(
                            id="proposal-search",
                            type="search",
                            placeholder="Search file, source system, uploader…",
                            style={
                                "width": "100%",
                                "height": "38px",
                                "border": "1px solid {}".format(COLORS["line"]),
                                "borderRadius": "7px",
                                "padding": "0 11px",
                                "boxSizing": "border-box",
                            },
                        ),
                    ],
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "220px minmax(240px, 1fr)",
                        "gap": "10px",
                        "margin": "16px 0 12px",
                    },
                ),
                html.Div(id="proposal-load-error"),
                dash_table.DataTable(
                    id="proposal-table",
                    columns=[
                        {"name": "Status", "id": "status"},
                        {"name": "File", "id": "file_name"},
                        {"name": "Source", "id": "source_system"},
                        {"name": "Uploader", "id": "uploaded_by"},
                        {"name": "Confidence", "id": "confidence", "type": "numeric", "format": {"specifier": ".2f"}},
                        {"name": "Mapped", "id": "mapped", "type": "numeric"},
                        {"name": "Review", "id": "review", "type": "numeric"},
                        {"name": "Others", "id": "others", "type": "numeric"},
                    ],
                    data=[],
                    row_selectable="single",
                    selected_rows=[],
                    page_size=12,
                    sort_action="native",
                    style_table={"overflowX": "auto"},
                    style_cell={
                        "padding": "10px",
                        "textAlign": "left",
                        "fontFamily": "Arial, sans-serif",
                        "fontSize": "13px",
                        "border": "1px solid {}".format(COLORS["line"]),
                        "maxWidth": "260px",
                        "overflow": "hidden",
                        "textOverflow": "ellipsis",
                    },
                    style_header={
                        "background": COLORS["canvas"],
                        "fontWeight": "800",
                        "color": COLORS["ink"],
                    },
                    style_data_conditional=[
                        {
                            "if": {"state": "selected"},
                            "backgroundColor": COLORS["primary_soft"],
                            "border": "1px solid {}".format(COLORS["primary"]),
                        }
                    ],
                ),
            ],
            style=CARD_STYLE,
        ),
        html.Div(
            [
                html.H2("Selected mapping", style={"marginTop": "0"}),
                html.Div(
                    "Select a proposal above to inspect and edit its column mappings.",
                    id="selected-file-detail",
                    style={"color": COLORS["muted"], "marginBottom": "14px"},
                ),
                dash_table.DataTable(
                    id="mapping-editor",
                    columns=[
                        {"name": "#", "id": "source_position", "type": "numeric", "editable": False},
                        {"name": "Source column", "id": "source_name", "editable": False},
                        {"name": "Inferred meaning", "id": "inferred_meaning", "editable": False},
                        {"name": "Standard column", "id": "suggested_standard_name", "presentation": "dropdown", "editable": True},
                        {"name": "Source format", "id": "detected_source_format", "editable": True},
                        {"name": "Confidence", "id": "confidence", "type": "numeric", "editable": False, "format": {"specifier": ".2f"}},
                        {"name": "Reason", "id": "reason", "editable": False},
                    ],
                    data=[],
                    dropdown={},
                    editable=True,
                    page_action="none",
                    style_table={"overflowX": "auto", "maxHeight": "520px", "overflowY": "auto"},
                    style_cell={
                        "padding": "9px",
                        "textAlign": "left",
                        "fontFamily": "Arial, sans-serif",
                        "fontSize": "13px",
                        "whiteSpace": "normal",
                        "height": "auto",
                        "minWidth": "90px",
                        "maxWidth": "260px",
                        "border": "1px solid {}".format(COLORS["line"]),
                    },
                    style_header={"background": COLORS["canvas"], "fontWeight": "800"},
                ),
                html.Label(
                    "Reviewer note",
                    style={"display": "block", "fontWeight": "750", "margin": "16px 0 6px"},
                ),
                dcc.Textarea(
                    id="review-note",
                    placeholder="Optional for approval; required when rejecting.",
                    maxLength=2000,
                    style={
                        "width": "100%",
                        "minHeight": "78px",
                        "border": "1px solid {}".format(COLORS["line"]),
                        "borderRadius": "8px",
                        "padding": "10px",
                        "boxSizing": "border-box",
                    },
                ),
                dcc.Checklist(
                    id="review-confirmation",
                    options=[{
                        "label": " I confirm that I reviewed every source-to-standard mapping.",
                        "value": "CONFIRMED",
                    }],
                    value=[],
                    style={"margin": "13px 0"},
                ),
                html.Div(
                    [
                        html.Button("Approve mapping", id="approve-mapping", n_clicks=0, style=BUTTON_STYLE),
                        html.Button(
                            "Reject mapping",
                            id="reject-mapping",
                            n_clicks=0,
                            style={**BUTTON_STYLE, "background": COLORS["danger"]},
                        ),
                    ],
                    style={"display": "flex", "gap": "10px", "flexWrap": "wrap"},
                ),
                html.Div(id="decision-result"),
            ],
            style={**CARD_STYLE, "marginTop": "16px"},
        ),
    ],
    style={
        "maxWidth": "1500px",
        "margin": "0 auto",
        "padding": "28px",
        "fontFamily": "Arial, sans-serif",
        "color": COLORS["ink"],
        "background": COLORS["canvas"],
        "minHeight": "100vh",
        "boxSizing": "border-box",
    },
)


@app.callback(
    Output("scenario-message", "children"),
    Input("run-prepare", "n_clicks"),
    prevent_initial_call=True,
)
def run_prepare_scenario(prepare_clicks):
    scenario_id = scenario_id_from_variable(
        "PREPARE_MAPPING_SCENARIO_ID", PREPARE_SCENARIO_DEFAULT
    )
    try:
        username = get_authenticated_user()
        scenario = project.get_scenario(scenario_id)
        current = scenario.get_current_run()
        if current is not None and current.running:
            return decision_banner(
                "{} is already running.".format(scenario_id), "warning"
            )
        scenario.run(params={
            "requested_by": username,
            "requested_from": "DATA_ADMIN_PORTAL",
        })
        return decision_banner(
            "{} was queued by {}.".format(scenario_id, username), "success"
        )
    except Exception as error:
        return decision_banner(str(error), "danger")


@app.callback(
    Output("prepare-status", "children"),
    Input("status-poll", "n_intervals"),
)
def refresh_prepare_scenario_status(_):
    scenario_id = scenario_id_from_variable(
        "PREPARE_MAPPING_SCENARIO_ID", PREPARE_SCENARIO_DEFAULT
    )
    status, detail = scenario_summary(scenario_id)
    return status_pill(status, detail)


@app.callback(
    Output("proposal-table", "data"),
    Output("summary-cards", "children"),
    Output("proposal-load-error", "children"),
    Input("refresh-proposals", "n_clicks"),
    Input("status-filter", "value"),
    Input("proposal-search", "value"),
    Input("approval-event", "data"),
)
def refresh_proposals(_, status_filter, search_text, approval_event):
    try:
        all_records = dashboard_records("ALL", "")
        records = dashboard_records(status_filter, search_text)
        counts = {
            status: sum(record["status"] == status for record in all_records)
            for status in ["REVIEW", "PENDING", "APPROVED", "REJECTED", "ERROR"]
        }
        cards = html.Div(
            [
                summary_card("Needs review", counts["REVIEW"], COLORS["warning"]),
                summary_card("Pending", counts["PENDING"], COLORS["primary"]),
                summary_card("Approved", counts["APPROVED"], COLORS["success"]),
                summary_card("Rejected", counts["REJECTED"], COLORS["danger"]),
                summary_card("Errors", counts["ERROR"], COLORS["danger"]),
            ],
            style={
                "display": "grid",
                "gridTemplateColumns": "repeat(auto-fit, minmax(140px, 1fr))",
                "gap": "10px",
            },
        )
        return records, cards, ""
    except Exception as error:
        return [], "", decision_banner(str(error), "danger")


@app.callback(
    Output("selected-proposal", "data"),
    Output("selected-file-detail", "children"),
    Output("mapping-editor", "data"),
    Output("mapping-editor", "dropdown"),
    Output("review-note", "value"),
    Output("review-confirmation", "value"),
    Input("proposal-table", "selected_rows"),
    State("proposal-table", "data"),
)
def select_proposal(selected_rows, table_data):
    if not selected_rows:
        raise PreventUpdate
    selected_index = selected_rows[0]
    if selected_index >= len(table_data or []):
        raise PreventUpdate

    selected = table_data[selected_index]
    try:
        proposal = find_proposal(
            selected.get("mapping_id", ""),
            selected.get("sample_fingerprint", ""),
        )
        standards, _ = load_standards()
        reasons = json_value(proposal.get("review_reasons_json"), list, [])
        detail = html.Div([
            html.Div([
                html.Strong(text_value(proposal.get("file_name"))),
                html.Span(
                    " · {} · contract {} · cleaning {}".format(
                        selected.get("status"),
                        text_value(proposal.get("column_contract_version")),
                        text_value(proposal.get("cleaning_standard_version")),
                    ),
                    style={"color": COLORS["muted"]},
                ),
            ]),
            html.Div(
                "Review reasons: {}".format("; ".join(reasons) if reasons else "None"),
                style={"fontSize": "13px", "marginTop": "5px", "color": COLORS["muted"]},
            ),
        ])
        dropdown = {
            "suggested_standard_name": {
                "options": [
                    {"label": name, "value": name}
                    for name in standards
                ]
            }
        }
        selection = {
            "mapping_id": selected.get("mapping_id"),
            "sample_fingerprint": selected.get("sample_fingerprint"),
        }
        return selection, detail, editor_rows(proposal), dropdown, "", []
    except Exception as error:
        return None, decision_banner(str(error), "danger"), [], {}, "", []


@app.callback(
    Output("decision-result", "children"),
    Output("approval-event", "data"),
    Input("approve-mapping", "n_clicks"),
    Input("reject-mapping", "n_clicks"),
    State("selected-proposal", "data"),
    State("mapping-editor", "data"),
    State("review-note", "value"),
    State("review-confirmation", "value"),
    prevent_initial_call=True,
)
def save_decision(
    approve_clicks,
    reject_clicks,
    selected,
    edited_rows,
    note,
    confirmation,
):
    triggered = callback_context.triggered[0]["prop_id"].split(".")[0]
    decision = "APPROVED" if triggered == "approve-mapping" else "REJECTED"
    try:
        if not selected:
            raise ValueError("Select a mapping proposal first.")
        if "CONFIRMED" not in (confirmation or []):
            raise ValueError("Confirm that you reviewed every mapping first.")
        if decision == "REJECTED" and not text_value(note).strip():
            raise ValueError("Enter a reviewer note explaining the rejection.")

        proposal = find_proposal(
            selected.get("mapping_id", ""),
            selected.get("sample_fingerprint", ""),
        )
        if text_value(proposal.get("understanding_status")).upper() != "SUCCESS":
            raise ValueError("A failed LLM proposal cannot be approved or rejected.")

        standards, contract_version = load_standards()
        if contract_version != text_value(proposal.get("column_contract_version")):
            raise ValueError(
                "The column contract changed after this proposal was generated. "
                "Run the prepare flow again before reviewing it."
            )
        cleaning_version = load_cleaning_standard_version()
        if cleaning_version != text_value(
            proposal.get("cleaning_standard_version")
        ):
            raise ValueError(
                "The cleaning standard changed after this proposal was generated. "
                "Run the prepare flow again before reviewing it."
            )
        reviewed = prepare_reviewed_mappings(
            proposal,
            edited_rows,
            standards,
            enforce_approval_rules=(decision == "APPROVED"),
        )
        username = get_authenticated_user()
        event = append_catalog_decision(
            proposal, reviewed, decision, note, username
        )
        return (
            decision_banner(
                "Mapping {} by {} at {}.".format(
                    decision.lower(), username, event["reviewed_at_gmt8"]
                ),
                "success" if decision == "APPROVED" else "warning",
            ),
            {
                "decision_id": event["decision_id"],
                "mapping_id": event["mapping_id"],
                "decision": decision,
            },
        )
    except Exception as error:
        return decision_banner(str(error), "danger"), None
