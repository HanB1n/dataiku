# -*- coding: utf-8 -*-
"""Load the simplified organizational column contract into Dataiku.

Input:  managed folder TaQLwGYy containing standard_column_contract.json
Output: Standard-Column-Contract

The output contains one row per standard column. Array and object values are
stored as compact JSON strings so the dataset remains portable.
"""

import json
import os

import dataiku
import pandas as pd


CONTRACT_FOLDER_ID = "TaQLwGYy"
CONTRACT_FILE_NAME = "standard_column_contract.json"
OUTPUT_DATASET = "Column-Standard"

ROOT_FIELDS = {"version", "columns"}
COLUMN_FIELDS = {
    "standard_name",
    "definition",
    "mapping_guidance",
    "known_aliases",
    "semantic_type",
    "spark_type",
    "nullable",
    "target_format",
    "cleaning_rule_id",
    "validation_rule_id",
}


contract_folder = dataiku.Folder(CONTRACT_FOLDER_ID)
output_dataset = dataiku.Dataset(OUTPUT_DATASET)


def compact_json(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def find_contract_path():
    matches = [
        path
        for path in contract_folder.list_paths_in_partition()
        if os.path.basename(path.rstrip("/")) == CONTRACT_FILE_NAME
    ]
    if not matches:
        raise ValueError(
            "{} was not found in managed folder {}".format(
                CONTRACT_FILE_NAME, CONTRACT_FOLDER_ID
            )
        )
    if len(matches) > 1:
        raise ValueError(
            "More than one {} file was found: {}".format(
                CONTRACT_FILE_NAME, ", ".join(sorted(matches))
            )
        )
    return matches[0]


def validate_contract(contract):
    if not isinstance(contract, dict):
        raise ValueError("The contract root must be a JSON object")

    missing_root = sorted(ROOT_FIELDS - set(contract))
    extra_root = sorted(set(contract) - ROOT_FIELDS)
    if missing_root:
        raise ValueError("Missing root fields: {}".format(", ".join(missing_root)))
    if extra_root:
        raise ValueError("Unsupported root fields: {}".format(", ".join(extra_root)))
    if not isinstance(contract["version"], str) or not contract["version"].strip():
        raise ValueError("version must be a non-empty string")
    if not isinstance(contract["columns"], list) or not contract["columns"]:
        raise ValueError("columns must be a non-empty array")

    standard_names = []
    for position, column in enumerate(contract["columns"], start=1):
        if not isinstance(column, dict):
            raise ValueError("Column {} must be a JSON object".format(position))

        missing = sorted(COLUMN_FIELDS - set(column))
        extra = sorted(set(column) - COLUMN_FIELDS)
        if missing:
            raise ValueError(
                "Column {} is missing: {}".format(position, ", ".join(missing))
            )
        if extra:
            raise ValueError(
                "Column {} has unsupported fields: {}".format(
                    position, ", ".join(extra)
                )
            )

        for field in (
            "standard_name",
            "definition",
            "mapping_guidance",
            "semantic_type",
            "spark_type",
            "cleaning_rule_id",
            "validation_rule_id",
        ):
            if not isinstance(column[field], str) or not column[field].strip():
                raise ValueError(
                    "Column {} field {} must be a non-empty string".format(
                        position, field
                    )
                )
        if not isinstance(column["known_aliases"], list):
            raise ValueError("Column {} known_aliases must be an array".format(position))
        if not all(isinstance(alias, str) for alias in column["known_aliases"]):
            raise ValueError(
                "Column {} known_aliases must contain only strings".format(position)
            )
        if not isinstance(column["nullable"], bool):
            raise ValueError("Column {} nullable must be true or false".format(position))
        if not isinstance(column["target_format"], dict):
            raise ValueError("Column {} target_format must be an object".format(position))

        standard_names.append(column["standard_name"].strip())

    duplicates = sorted(
        {name for name in standard_names if standard_names.count(name) > 1}
    )
    if duplicates:
        raise ValueError(
            "Duplicate standard_name values: {}".format(", ".join(duplicates))
        )


contract_path = find_contract_path()
with contract_folder.get_download_stream(contract_path) as stream:
    raw_contract = stream.read()

try:
    contract = json.loads(raw_contract.decode("utf-8-sig"))
except (UnicodeDecodeError, json.JSONDecodeError) as error:
    raise ValueError("The contract is not valid UTF-8 JSON: {}".format(error))

validate_contract(contract)

rows = []
for column in contract["columns"]:
    rows.append(
        {
            "version": contract["version"],
            "standard_name": column["standard_name"],
            "definition": column["definition"],
            "mapping_guidance": column["mapping_guidance"],
            "known_aliases": compact_json(column["known_aliases"]),
            "semantic_type": column["semantic_type"],
            "spark_type": column["spark_type"],
            "nullable": column["nullable"],
            "target_format": compact_json(column["target_format"]),
            "cleaning_rule_id": column["cleaning_rule_id"],
            "validation_rule_id": column["validation_rule_id"],
        }
    )

output_dataset.write_with_schema(pd.DataFrame(rows))
