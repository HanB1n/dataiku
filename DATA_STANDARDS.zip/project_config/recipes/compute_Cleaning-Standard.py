# -*- coding: utf-8 -*-
"""Load the standard cleaning-rule catalog into Dataiku.

Input:  managed folder TaQLwGYy containing standard_cleaning_rules.json
Output: Cleaning-Standard

The output contains one row per cleaning rule. The ordered operation list is
stored as compact JSON for portability across Dataiku and external systems.
"""

import json
import os

import dataiku
import pandas as pd


CONTRACT_FOLDER_ID = "TaQLwGYy"
RULE_FILE_NAME = "standard_cleaning_rules.json"
OUTPUT_DATASET = "Cleaning-Standard"

ROOT_FIELDS = {"version", "rules"}
RULE_FIELDS = {
    "cleaning_rule_id",
    "description",
    "input_spark_type",
    "output_spark_type",
    "null_handling",
    "invalid_value_action",
    "operations",
}


contract_folder = dataiku.Folder(CONTRACT_FOLDER_ID)
output_dataset = dataiku.Dataset(OUTPUT_DATASET)


def compact_json(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def find_rule_path():
    matches = [
        path
        for path in contract_folder.list_paths_in_partition()
        if os.path.basename(path.rstrip("/")) == RULE_FILE_NAME
    ]
    if not matches:
        raise ValueError(
            "{} was not found in managed folder {}".format(
                RULE_FILE_NAME, CONTRACT_FOLDER_ID
            )
        )
    if len(matches) > 1:
        raise ValueError(
            "More than one {} file was found: {}".format(
                RULE_FILE_NAME, ", ".join(sorted(matches))
            )
        )
    return matches[0]


def validate_catalog(catalog):
    if not isinstance(catalog, dict):
        raise ValueError("The cleaning catalog root must be a JSON object")

    missing_root = sorted(ROOT_FIELDS - set(catalog))
    extra_root = sorted(set(catalog) - ROOT_FIELDS)
    if missing_root:
        raise ValueError("Missing root fields: {}".format(", ".join(missing_root)))
    if extra_root:
        raise ValueError("Unsupported root fields: {}".format(", ".join(extra_root)))
    if not isinstance(catalog["version"], str) or not catalog["version"].strip():
        raise ValueError("version must be a non-empty string")
    if not isinstance(catalog["rules"], list) or not catalog["rules"]:
        raise ValueError("rules must be a non-empty array")

    rule_ids = []
    for position, rule in enumerate(catalog["rules"], start=1):
        if not isinstance(rule, dict):
            raise ValueError("Rule {} must be a JSON object".format(position))

        missing = sorted(RULE_FIELDS - set(rule))
        extra = sorted(set(rule) - RULE_FIELDS)
        if missing:
            raise ValueError(
                "Rule {} is missing: {}".format(position, ", ".join(missing))
            )
        if extra:
            raise ValueError(
                "Rule {} has unsupported fields: {}".format(
                    position, ", ".join(extra)
                )
            )

        for field in (
            "cleaning_rule_id",
            "description",
            "input_spark_type",
            "output_spark_type",
            "null_handling",
            "invalid_value_action",
        ):
            if not isinstance(rule[field], str) or not rule[field].strip():
                raise ValueError(
                    "Rule {} field {} must be a non-empty string".format(
                        position, field
                    )
                )

        operations = rule["operations"]
        if not isinstance(operations, list) or not operations:
            raise ValueError("Rule {} operations must be non-empty".format(position))

        expected_orders = list(range(1, len(operations) + 1))
        actual_orders = []
        for operation_position, operation in enumerate(operations, start=1):
            if not isinstance(operation, dict):
                raise ValueError(
                    "Rule {} operation {} must be an object".format(
                        position, operation_position
                    )
                )
            if not isinstance(operation.get("operation"), str) or not operation[
                "operation"
            ].strip():
                raise ValueError(
                    "Rule {} operation {} needs an operation name".format(
                        position, operation_position
                    )
                )
            actual_orders.append(operation.get("order"))
        if actual_orders != expected_orders:
            raise ValueError(
                "Rule {} operation order must be consecutive from 1".format(position)
            )

        rule_ids.append(rule["cleaning_rule_id"].strip())

    duplicates = sorted({rule_id for rule_id in rule_ids if rule_ids.count(rule_id) > 1})
    if duplicates:
        raise ValueError("Duplicate cleaning_rule_id values: {}".format(", ".join(duplicates)))


rule_path = find_rule_path()
with contract_folder.get_download_stream(rule_path) as stream:
    raw_catalog = stream.read()

try:
    catalog = json.loads(raw_catalog.decode("utf-8-sig"))
except (UnicodeDecodeError, json.JSONDecodeError) as error:
    raise ValueError("The cleaning catalog is not valid UTF-8 JSON: {}".format(error))

validate_catalog(catalog)

rows = []
for rule in catalog["rules"]:
    rows.append(
        {
            "version": catalog["version"],
            "cleaning_rule_id": rule["cleaning_rule_id"],
            "description": rule["description"],
            "input_spark_type": rule["input_spark_type"],
            "output_spark_type": rule["output_spark_type"],
            "null_handling": rule["null_handling"],
            "invalid_value_action": rule["invalid_value_action"],
            "operations": compact_json(rule["operations"]),
        }
    )

output_dataset.write_with_schema(pd.DataFrame(rows))
